package com.bank.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.dao.BankDao;
import com.bank.model.BankModel;

@Service
public class BankService {
@Autowired
BankDao dao;

public List<BankModel> getAllData() {
	List<BankModel> li = new ArrayList<BankModel>();
	dao.findAll().forEach(li1 -> li.add(li1));
	return li;
}

public void saveData(BankModel bankmodel) {
	// TODO Auto-generated method stub
	dao.save(bankmodel);
}

public void bankDelete(int bankid) {
	// TODO Auto-generated method stub
	dao.deleteById(bankid);
}

public BankModel updateData(int bankid) {
	return dao.findById(bankid).get();
}


}
