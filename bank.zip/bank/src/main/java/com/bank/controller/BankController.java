package com.bank.controller;

import java.util.List;
import java.util.OptionalDouble;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.bank.model.BankModel;
import com.bank.service.BankService;

@Controller
public class BankController {
	@Autowired
	BankService ser;

	@GetMapping("/getall")
	private String getAllBank(Model model) {
		List<BankModel> listmodel = ser.getAllData();
		model.addAttribute("datas", listmodel);
		return "index";
	}

	@GetMapping("/addbank")
	private String addBank(Model model) {
		BankModel bankmodel = new BankModel();
		model.addAttribute("bankmodel", bankmodel);
		return "addbank";
	}

	@PostMapping("/savebank")
	private String saveBank(@ModelAttribute("savebank") BankModel bankmodel) {
		ser.saveData(bankmodel);
		return "redirect:/getall";
	}

	@RequestMapping("/deletebank/{bankId}")
	private String bankDelete(@PathVariable("bankId") int bankid) {
		ser.bankDelete(bankid);
		return "redirect:/getall";
	}

	@GetMapping("/updatebank/{bankId}")
	private String bankUpdate(@PathVariable("bankId") int bankid, Model model) {
		model.addAttribute("bankupdate", ser.updateData(bankid));
		return "bankupd";
	}

	@GetMapping("/viewpage")
	private String viewpage(Model model) {
		List<BankModel> listmodel = ser.getAllData();
		model.addAttribute("datas", listmodel);
		// return "index";

		return "viewpage";
	}
	
	
	@GetMapping("/selectbank")
	private String selectbank(@RequestParam("selectedBank") String selectedBank, @RequestParam("amount") int amout,Model model) {
		//System.out.println("selectedBank::::::::::::::::::>"+ selectedBank);
		//System.out.println("amout::::::::::::::::::>"+ amout);
		
		 String selectedBankName = selectedBank;

	        // Retrieve the selected bank's data from the database based on the bank name
	        List<BankModel> bankDataList = ser.getAllData();

	        OptionalDouble interestRate = bankDataList
	                .stream()
	                .filter(bank -> bank.getBankName().equals(selectedBankName))
	                .mapToDouble(BankModel::getInterest)
	                .average();

	        if (interestRate.isPresent()) {
	            // Calculate the rate of interest (average interest rate)
	            double averageInterestRate = interestRate.getAsDouble();
	            double calculatedInterest = (amout * averageInterestRate) / 100; // Assuming interest is in percentage
	            //System.out.println("averageInterestRate::::::"+ calculatedInterest);
                double totalAmount = calculatedInterest + amout;
              //  System.out.println("totalAmount "+totalAmount);
                model.addAttribute("BankName", selectedBank);
                model.addAttribute("amount", amout);
                model.addAttribute("calculatedInterest", calculatedInterest);
	            model.addAttribute("interestRate", totalAmount);
	            
	        } else {
	            // Handle the case where the bank data is not found
	            model.addAttribute("errorMessage", "Bank not found");
	        }
		

		return "viewpage";
	}
}
