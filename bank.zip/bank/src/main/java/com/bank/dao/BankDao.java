package com.bank.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bank.model.BankModel;

public interface BankDao extends JpaRepository<BankModel,Integer>{

}
